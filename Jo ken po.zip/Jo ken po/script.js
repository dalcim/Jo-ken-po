	
    alert("Pedra vence tesoura, Tesoura vence papel e Papel vence pedra")
	
	
	alert("Pronto para iniciar o jogo? Clique em ok.")
    var escolhaUsu = prompt("Voce escolhe pedra, papel ou tesoura?");
    var escolhaPc = Math.random();
    if (escolhaPc < 0.34) {
        escolhaPc = "pedra";
    } else if (escolhaPc <= 0.67) {
        escolhaPc = "papel";
    } else {
        escolhaPc = "tesoura";
    }
     alert("Computador: " + escolhaPc);
    
    var compare = function (escolha1, escolha2) {
        if (escolha1 === escolha2)
            return ("O resultado eh um empate!")
        else if (escolha1 === "pedra") {
            if (escolha2 === "tesoura")
                return ("pedra vence")
            else {
                return ("papel vence")
            }
        }
        else if (escolha1 === "papel") {
            if (escolha2 === "pedra")
                return "papel vence"
            else {
                return "tesoura vence"
            }
        }
        else if (escolha1 === "tesoura") {
            if (escolha2 === "pedra")
                return "pedra vence"
            else {
                return "tesoura vence"
            }
        }
    };
   alert(compare(escolhaUsu, escolhaPc))
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

 
	